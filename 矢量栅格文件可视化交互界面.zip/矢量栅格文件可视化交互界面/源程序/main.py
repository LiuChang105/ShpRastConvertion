############################################
class ORDER:
    def __init__(self, ORD, Filename):
        self.ORD = ORD
        self.Filename = Filename


############################################
class PAL:
    def __init__(self, Narc, XL, YL, AID, ENP, OPG):
        self.Narc = Narc
        self.XL = XL
        self.YL = YL
        self.AID = AID
        self.ENP = ENP
        self.OPG = OPG


############################################
class ARC:
    def __init__(self, AID, FID, STP, ENP, LPG, RPG, NP, Pxlist, Pylist):
        self.AID = AID
        self.FID = FID
        self.STP = STP
        self.ENP = ENP
        self.LPG = LPG
        self.RPG = RPG
        self.NP = NP
        self.Pxlist = Pxlist
        self.Pylist = Pylist


class RastFile:
    def __init__(self, FBL, Xs, Ys, RAST, Mxs, Mys):
        self.FBL = FBL
        self.Xs = Xs
        self.Ys = Ys
        self.RAST = RAST
        self.Mxs = Mxs
        self.Mys = Mys


############################################
def arcplot(x, y):
    global toEast
    global toNorth
    turtle.penup()
    turtle.pencolor(0, 0, 0)  # 函数表示小乌龟运动轨迹的颜色
    turtle.goto(x[0] - edge / 2 + toEast, y[0] + toNorth)
    turtle.pd()
    for i in range(1, len(x)):
        turtle.goto(x[i] - edge / 2 + toEast, y[i] + toNorth)
    turtle.hideturtle()  # 隐藏画笔
    turtle.update()
    return


############################################
def readarcs(Filename):
    # file = open(Filename, "r")  # r表示只读模式
    try:
        with open(Filename, 'r') as file:
            content = file.read()  # 将文件内容存储在str content中
            file.close()  # 关闭文件
    except FileNotFoundError:
        tk.messagebox.showerror("错误", "矢量文件不存在。\n请输入正确的矢量文件路径。")
        return -1
    except OSError:
        tk.messagebox.showerror("错误", "矢量文件路径不合法。\n请输入正确的矢量文件路径。")
        return -1
    index = content.find("35")
    i = content.find("ARC  2")
    arcs = []
    i = i + content[i:-1].find("\n") + 1
    while (content[i:i + 10] != "        -1"):
        while content[i] == ' ':
            i = i + 1
        aid = int(content[i:i + content[i:-1].find(" ")])
        i = i + content[i:-1].find(" ");
        while content[i] == ' ':
            i = i + 1
        fid = int(content[i:i + content[i:-1].find(" ")])
        i = i + content[i:-1].find(" ");
        while content[i] == ' ':
            i = i + 1
        stp = int(content[i:i + content[i:-1].find(" ")])
        i = i + content[i:-1].find(" ");
        while content[i] == ' ':
            i = i + 1
        enp = int(content[i:i + content[i:-1].find(" ")])
        i = i + content[i:-1].find(" ");
        while content[i] == ' ':
            i = i + 1
        lpg = int(content[i:i + content[i:-1].find(" ")])
        i = i + content[i:-1].find(" ");
        while content[i] == ' ':
            i = i + 1
        rpg = int(content[i:i + content[i:-1].find(" ")])
        i = i + content[i:-1].find(" ");
        while content[i] == ' ':
            i = i + 1
        np = int(content[i:i + content[i:-1].find("\n")])
        i = i + content[i:-1].find("\n") + 1
        pxlist = []
        pylist = []
        for ip in range(np):
            i = i + 1
            pxlist.append(float(content[i:i + 9]) * 10 ** int(content[i + 10:i + 13]))
            i = i + 14
            pylist.append(float(content[i:i + 9]) * 10 ** int(content[i + 10:i + 13]))
            i = i + 13
            if ip % 2 == 1:
                i = i + 1
        arcs.append(ARC(aid, fid, stp, enp, lpg, rpg, np, pxlist, pylist))
        if np % 2: i = i + content[i:-1].find("\n") + 1
    return arcs


############################################
def adjshp(arcs, mxs, mys):
    for i in range(len(arcs)):
        for j in range(arcs[i].NP):
            arcs[i].Pxlist[j] = (arcs[i].Pxlist[j] - mxs[0]) / (mxs[1] - mxs[0]) * width * zoom - width * zoom / 2
            arcs[i].Pylist[j] = (arcs[i].Pylist[j] - mys[0]) / (mys[1] - mys[0]) * height * zoom - height * zoom / 2
    return arcs


############################################
def readpal(Filename):
    try:
        with open(Filename, 'r') as file:
            content = file.read()  # 将文件内容存储在str content中
            file.close()  # 关闭文件
    except FileNotFoundError:
        tk.messagebox.showerror("错误", "矢量文件不存在。\n请输入正确的矢量文件路径。")
        return -1
    except OSError:
        tk.messagebox.showerror("错误", "矢量文件路径不合法。\n请输入正确的矢量文件路径。")
        return -1
    i = content.find("PAL  2")
    index = i + content[i:-1].find("        -1         0         0         0         0         0         0")
    pals = []
    i = i + content[i:-1].find("\n") + 1
    while (i < index):
        while content[i] < '0' or content[i] > '9':
            i = i + 1
        en = i
        while content[en] >= '0' and content[en] <= '9':
            en = en + 1
        narc = int(content[i:en])
        i = en
        xl = [];
        yl = [];
        while content[i] < '0' or content[i] > '9':
            i = i + 1
        en = i + content[i:-1].find("E") + 1
        xl.append(float(content[i:en - 1]) * 10 ** int(content[en:en + content[en:-1].find(" ")]))
        i = en + content[en:-1].find(" ")
        while content[i] < '0' or content[i] > '9':
            i = i + 1
        en = i + content[i:-1].find("E") + 1
        yl.append(float(content[i:en - 1]) * 10 ** int(content[en:en + content[en:-1].find(" ")]))
        i = en + content[en:-1].find(" ")
        while content[i] < '0' or content[i] > '9':
            i = i + 1
        en = i + content[i:-1].find("E") + 1
        xl.append(float(content[i:en - 1]) * 10 ** int(content[en:en + content[en:-1].find(" ")]))
        i = en + content[en:-1].find(" ")
        while content[i] < '0' or content[i] > '9':
            i = i + 1
        en = i + content[i:-1].find("E") + 1
        yl.append(float(content[i:en - 1]) * 10 ** int(content[en:en + content[en:-1].find(" ")]))
        i = en + content[en:-1].find(" ")

        aid = [];
        enp = [];
        opg = [];
        for arci in range(narc):
            while (content[i] < '0' or content[i] > '9') and content[i] != '-':
                i = i + 1
            en = i
            while (content[en] >= '0' and content[en] <= '9') or content[en] == '-':
                en = en + 1
            aid.append(int(content[i:en]))
            i = en + 1

            while (content[i] < '0' or content[i] > '9') and content[i] != '-':
                i = i + 1
            en = i
            while (content[en] >= '0' and content[en] <= '9') or content[en] == '-':
                en = en + 1
            enp.append(int(content[i:en]))
            i = en + 1

            while (content[i] < '0' or content[i] > '9') and content[i] != '-':
                i = i + 1
            en = i
            while (content[en] >= '0' and content[en] <= '9') or content[en] == '-':
                en = en + 1
            opg.append(int(content[i:en]))
            i = en + 1
        pals.append(PAL(narc, xl, yl, aid, enp, opg))
    return pals


############################################
def shpplot(Filename):
    # Filename=File
    pals = readpal(Filename)
    if pals == -1:
        return -1
    arcs = readarcs(Filename)
    if arcs == -1:
        return -1
    mxs = [9999999, 0]
    mys = [9999999, 0]
    for i in range(0, len(arcs)):
        mxs[0] = min(mxs[0], min(arcs[i].Pxlist))
        mxs[1] = max(mxs[1], max(arcs[i].Pxlist))
        mys[0] = min(mys[0], min(arcs[i].Pylist))
        mys[1] = max(mys[1], max(arcs[i].Pylist))
    arcs = adjshp(arcs, mxs, mys)

    '''
    for pal in pals[1:30]:
        for aid in pal.AID:
            for i in range(len(arcs)):
                if arcs[i].AID==abs(aid):
                    arcplot(arcs[i].Pxlist, arcs[i].Pylist)
                    break
    '''
    for arc in arcs[startarc:endarc]:
        arcplot(arc.Pxlist, arc.Pylist)
    return


############################################
def readrast(Filename):
    # Filename=RFile
    try:
        with open(Filename, 'r') as file:
            content = file.read()  # 将文件内容存储在str content中
            file.close()  # 关闭文件
    except FileNotFoundError:
        tk.messagebox.showerror("错误", "栅格文件不存在。\n请输入正确的栅格文件路径。")
        return -1
    except OSError:
        tk.messagebox.showerror("错误", "栅格文件路径不合法。\n请输入正确的矢量文件路径。")
        return -1
    mxs = [];
    mys = [];
    xs = [];
    ys = [];
    rast = [];
    i = 0
    fbl = float(content[i:i + content[i:-1].find(" ")])
    i = i + content[i:-1].find(" ") + 1
    nx = int(content[i:i + content[i:-1].find(" ")])
    i = i + content[i:-1].find(" ") + 1
    ny = int(content[i:i + content[i:-1].find(" ")])
    i = i + content[i:-1].find(" ") + 1
    mxs.append(float(content[i:i + content[i:-1].find(" ")]))
    i = i + content[i:-1].find(" ") + 1
    mys.append(float(content[i:i + content[i:-1].find(" ")]))
    i = i + content[i:-1].find(" ") + 1
    mxs.append(float(content[i:i + content[i:-1].find(" ")]))
    i = i + content[i:-1].find(" ") + 1
    mys.append(float(content[i:i + content[i:-1].find("\n")]))
    i = i + content[i:-1].find("\n") + 1

    for xi in range(nx):
        xs.append(float(content[i:i + content[i:-1].find(" ")]))
        i = i + content[i:-1].find(" ") + 1
    i = i + content[i:-1].find("\n") + 1
    for yi in range(ny):
        ys.append(float(content[i:i + content[i:-1].find(" ")]))
        i = i + content[i:-1].find(" ") + 1
    i = i + content[i:-1].find("\n") + 1
    
    
    index = i + content[i:-1].find("\n") - 3
    rastele=[]
    rastlen=[]
    while (i<index):#content[i:i+len("-1 0 0 0 0 0 0")]!="-1 0 0 0 0 0 0"
        rastele.append(int(content[i:i + content[i:-1].find(",")]))
        i = i + content[i:-1].find(",") + 1
        rastlen.append(int(content[i:i + content[i:-1].find(" ")]))
        i = i + content[i:-1].find(" ") + 1
    rast=[rastele,rastlen]
    '''
    for ri in range(nx):
        tmp = [];
        for ci in range(ny):
            tmp.append(int(content[i:i + content[i:-1].find(" ")]))
            i = i + content[i:-1].find(" ") + 1
        i = i + 1
        rast.append(tmp)
    '''
    return RastFile(fbl, xs, ys, rast, mxs, mys)


############################################
def rastplot(Rastfile):  #Rastfile
    global toEast
    global toNorth
    if Rastfile.Mxs[1] - Rastfile.Mxs[0]<Rastfile.Mys[1] - Rastfile.Mys[0]:
        fbl = (Rastfile.FBL) / (Rastfile.Mxs[1] - Rastfile.Mxs[0]) * width * zoom
    else:
        fbl = (Rastfile.FBL) / (Rastfile.Mys[1] - Rastfile.Mys[0]) * height * zoom
    rast = Rastfile.RAST
    wid = width * zoom
    hei = height * zoom
    ma = max(rast[0])
    mi = min(rast[0])    
    '''
    ma = -99999
    mi = 99999
    for i in range(len(rast)):
        ma = max(ma, max(rast[i]))
        mi = min(mi, min(rast[i]))
    '''
    xrange = [-wid / 2 + i * fbl for i in range(round((wid - 0) / fbl))]
    yrange = [-hei / 2 + i * fbl for i in range(round((hei - 0) / fbl))]
    turtle.penup()
    
    
    xi=0
    x = xrange[xi]
    yi=0
    y = yrange[yi]
    for i in range(len(rast[0])):#
        atr=rast[0][i]
        lenele=rast[1][i]
        #print(atr,lenele,sep=',',end=' ')
        #print(atr,lenele,sep=',')
        #print(xi,yi,sep=',',end=' -> ')
        turtle.goto(x - edge / 2 + toEast, y + toNorth)
        xi=xi+(yi+lenele)//len(yrange)
        if xi==len(xrange):break
        x = xrange[xi]
        yi=(yi+lenele)%len(yrange)
        y = yrange[yi]
        #print(xi,yi,sep=',')
        if atr == 0:continue
        turtle.begin_fill()
        turtle.fillcolor(1 - (atr % 6) / 6, 1 - (atr % 4) / 4, 1 - (atr % 5) / 5)
        turtle.setheading(0)
        turtle.fd(fbl)
        turtle.setheading(90)
        turtle.fd(fbl*lenele)
        turtle.setheading(180)
        turtle.fd(fbl)
        turtle.setheading(270)
        turtle.fd(fbl*lenele)
        turtle.end_fill()
        
    
    '''
    for xi in range(round((wid - 0) / fbl)):
        for yi in range(round((hei - 0) / fbl)):
            x = xrange[xi]
            y = yrange[yi]
            turtle.goto(x - edge / 2 + toEast, y + toNorth)
            turtle.begin_fill()
            atr = rast[xi][yi]
            if atr == 0: continue
            turtle.fillcolor(1 - (atr % 6) / 6, 1 - (atr % 4) / 4, 1 - (atr % 5) / 5)
            for ang in range(0, 360, 90):
                turtle.setheading(ang)
                turtle.fd(fbl)
            turtle.end_fill()
    '''
    
    turtle.hideturtle()  # 隐藏画笔
    turtle.update()
    return


############################################
def shp2raster(Filename, fenbl):
    #Filename="D:\lc_class\A地理信息系统\作业1\china.e00" #
    global width
    global height
    arcs = readarcs(Filename)
    if arcs == -1:
        return -1
    mxs = [9999999, 0]
    mys = [9999999, 0]
    for i in range(0, len(arcs)):
        mxs[0] = min(mxs[0], min(arcs[i].Pxlist))
        mxs[1] = max(mxs[1], max(arcs[i].Pxlist))
        mys[0] = min(mys[0], min(arcs[i].Pylist))
        mys[1] = max(mys[1], max(arcs[i].Pylist))
    arcs = adjshp(arcs, mxs, mys)
    pals = readpal(Filename)
    if pals == -1:
        return -1
    if mxs[1]-mxs[0]<mys[1]-mys[0]:
        fbl = fenbl/(mxs[1]-mxs[0])*width * zoom;
    else:
        fbl = fenbl/(mys[1]-mys[0])*height * zoom;
    wid = width * zoom;
    hei = height * zoom;
    xrange = [-wid / 2 + i * fbl - fbl for i in range(round((wid - 0) / fbl) + 2)]
    yrange = [-hei / 2 + i * fbl - fbl for i in range(round((hei - 0) / fbl) + 2)]
    rast = [[0 for j in range(round((hei - 0) / fbl) + 2)] for i in range(round((wid - 0) / fbl) + 2)]

    for arc in arcs[startarc:endarc]:
        x = arc.Pxlist[0];
        y = arc.Pylist[0];
        for i in range(1, arc.NP):  # rangeP
            xx = arc.Pxlist[i];
            yy = arc.Pylist[i];
            if yy == y:
                continue
            else:
                if yy > y:
                    delt = arc.LPG - arc.RPG;
                    di = 1;
                    for yi in range(len(yrange)):
                        if yrange[yi] + fbl / 2 >= y: break
                else:
                    delt = arc.RPG - arc.LPG;
                    di = -1;
                    for yi in range(len(yrange) - 1, -1, -1):
                        if yrange[yi] + fbl / 2 <= y: break
            a = (xx - x) / (yy - y);
            b = x - a * y;
            # yi=round((y+hei/2)/fbl)
            # if yi==len(yrange):yi=len(yrange)-1

            while di * (yrange[yi] + fbl / 2 - yy) <= 0:
                # print("yi",yi,sep='')#
                xi = 0
                while xrange[xi] + fbl / 2 <= a * (yrange[yi] + fbl / 2) + b:
                    # print("xi",xi,sep='')#
                    rast[xi][yi] = rast[xi][yi] + delt
                    xi = xi + 1
                    if xi >= len(xrange): break
                yi = yi + di
                if yi >= len(yrange) or yi < 0: break
            x = xx;
            y = yy;
    for i in range(len(rast)):
        rast[i] = rast[i][1:-1]

    return RastFile(fenbl, xrange[1:-1], yrange[1:-1], rast[1:-1], mxs, mys)


############################################
def RastFile2txt(Filename, RastFile):  # 链码
    #Filename="D:\lc_class\A地理信息系统\作业1\china推荐" #
    # RastFile=rastfile
    file = open(Filename, 'w')
    mxs = RastFile.Mxs
    mys = RastFile.Mys
    fbl = RastFile.FBL #/ width * (mxs[1] - mxs[0])
    content = str(fbl) + " " + str(len(RastFile.Xs)) + " " + str(len(RastFile.Ys)) + " " + str(mxs[0]) + " " + str(
        mys[0]) + " " + str(mxs[1]) + " " + str(mys[1]) + "\n"
    for x in RastFile.Xs:
        content = content + str((x + width * zoom / 2) / width / zoom * (mxs[1] - mxs[0]) + mxs[0]) + " "
    content = content + "\n"
    for y in RastFile.Ys:
        content = content + str((y + height * zoom / 2) / height / zoom * (mys[1] - mys[0]) + mys[0]) + " "
    content = content + "\n"
    
    chnrast=""
    for row in RastFile.RAST:
        for ele in row:
            chnrast=chnrast+str(ele)+'\t'
        chnrast=chnrast+'\n'
    '''
    nf="D:\lc_class\A地理信息系统\作业1\源程序\china.txt"
    nfile = open(nf, 'w')
    nfile.write(chnrast)
    nfile.close()
    '''
    for row in RastFile.RAST:
        lastele=row[0]
        lenele=1
        for i in range(1,len(row)):
            #print(row)
            #print(len(row))
            #print(None.shape)
            ele=row[i]
            if ele!=lastele:
                content = content + str(lastele)+','+str(lenele)+' '
                #print(str(lastele)+','+str(lenele)+' ')
                #print(lastele,lenele,sep=',')
                lastele=ele
                lenele=1
            else:
                lenele=lenele+1
        content = content + str(lastele)+','+str(lenele)+' '
        #print(None.shape)
    content = content + "\n-1 0 0 0 0 0 0"
    
    file.write(content)
    file.close()
    tk.messagebox.showinfo("提示信息", f"栅格文件已生成，路径{Filename}")


############################################
def clearscreen():
    global curq
    global q
    while q[curq].empty() == False:
        q[curq].get()
    turtle.clear()
    turtle.update()
    return


############################################
def ZoomIn():
    global zoom
    zoom = zoom + 0.1
    ReDraw()
    return


############################################
def ZoomOut():
    global zoom
    if zoom - 0.1 <= 0:
        tk.messagebox.showerror("错误", "已经缩到最小了，不能再缩小了。")
        return
    zoom = zoom - 0.1
    ReDraw()
    return


############################################
def MoveUp():
    global toNorth
    global step
    toNorth = toNorth - step
    ReDraw()
    return


############################################
def MoveDown():
    global toNorth
    global step
    toNorth = toNorth + step
    ReDraw()
    return


############################################
def MoveLeft():
    global toEast
    global step
    toEast = toEast + step
    ReDraw()
    return


############################################
def MoveRight():
    global toEast
    global step
    toEast = toEast - step
    ReDraw()
    return


############################################
def ReDraw():
    global curq
    global q
    turtle.clear()
    while q[curq].empty() == False:
        order = q[curq].get()
        if order.ORD == 1:
            shpp = shpplot(order.Filename)
        else:
            rastfile = readrast(order.Filename)
            rastplot(rastfile)
        q[1 - curq].put(order)
    curq = 1 - curq
    turtle.update()


############################################
def sFile_input():
    File = entry1.get()
    if File[0] == '"' and File[-1] == '"': File = File[1:-1]
    shpp = shpplot(File)
    if shpp == -1: return -1
    q[curq].put(ORDER(1, File))
    return


def rFile_input():
    File = entry2.get()
    if File[0] == '"' and File[-1] == '"': File = File[1:-1]
    rastfile = readrast(File)
    if rastfile == -1:
        return -1
    rastplot(rastfile)
    q[curq].put(ORDER(2, File))
    return


def s2rFile_input():
    SFile = entry3.get()
    if SFile[0] == '"' and SFile[-1] == '"': SFile = SFile[1:-1]
    RFile = entry4.get()
    if RFile[0] == '"' and RFile[-1] == '"': RFile = RFile[1:-1]
    fenbl = entry5.get()
    if SFile == '':
        tk.messagebox.showerror("错误", "未输入矢量文件路径。\n请重新输入。")
        return
    if RFile == '':
        tk.messagebox.showerror("错误", "未输入栅格文件路径。\n请重新输入")
        return
    if fenbl == '':
        tk.messagebox.showerror("错误", "未输入分辨率。\n请重新输入")
        return
    fenbl = float(fenbl)
    rastfile = shp2raster(SFile, fenbl)
    if rastfile == -1:
        return -1
    RastFile2txt(RFile, rastfile)
    return


############################################
def show_selection(value):
    global step
    step = int(value)

############################################
def Recfbl():
    global fenbl
    SFile = entry3.get()
    if SFile[0] == '"' and SFile[-1] == '"': SFile = SFile[1:-1]
    if SFile == '':
        tk.messagebox.showerror("错误", "未输入矢量文件路径。\n请重新输入。")
        return
    arcs = readarcs(SFile)
    if arcs == -1:
        return -1
    mxs = [9999999, 0]
    mys = [9999999, 0]
    for i in range(0, len(arcs)):
        mxs[0] = min(mxs[0], min(arcs[i].Pxlist))
        mxs[1] = max(mxs[1], max(arcs[i].Pxlist))
        mys[0] = min(mys[0], min(arcs[i].Pylist))
        mys[1] = max(mys[1], max(arcs[i].Pylist))
        rf=max((mxs[1]-mxs[0])/250,(mys[1]-mys[0])/250)
    fenbl=rf
    #egui.msgbox(f"推荐分辨率大小为{round(rf)}，该分辨率下长边约有250个格点。\n\n建议分辨率在{round(rf/2.3)}至{round(rf*4)}之间，\n分辨率太小易导致等待时间长，分辨率太大易导致不清晰。", "提示信息", "确定")
    tk.messagebox.showinfo("提示信息", f"推荐分辨率大小为{round(rf)}，该分辨率下长边约有250个格点。\n\n建议分辨率在{round(rf/2.3)}至{round(rf*4)}之间，分辨率太小易导致等待时间长，分辨率太大易导致不清晰。")


############################################
import random
import turtle
#import easygui as egui


startarc = 0  # 71黑龙江
endarc = -1  # 72黑龙江
# turtle.setup(width=0.5, height=0.75, startx=None, starty=None)
# width -- 如为一个整型数值，表示大小为多少像素，如为一个浮点数值，则表示屏幕的占比；默认为屏幕的 50%
# height -- 如为一个整型数值，表示高度为多少像素，如为一个浮点数值，则表示屏幕的占比；默认为屏幕的 75%
# startx -- 如为正值，表示初始位置距离屏幕左边缘多少像素，负值表示距离右边缘，None 表示窗口水平居中
# starty -- 如为正值，表示初始位置距离屏幕上边缘多少像素，负值表示距离下边缘，None 表示窗口垂直居中

# mxs=[520800.0, 5326140.0];
# mys=[80566.848, 4113200.0];
width = 500;
height = 500 / 1.2;
edge = 0;
# fenbl = 5;  # 分辨率
zoom = .95
toNorth = 0
toEast = 0
step = 10
fenbl=48053
turtle.setup(width + edge, height, -1, +100)
turtle.hideturtle()
turtle.tracer(0)

turtle.pensize(2)  # 表示小乌龟运动轨迹的宽度(线条粗细)
turtle.speed(speed=6)  # "fastest": 0 最快。"fast": 10 快。"normal": 6 正常。"slow": 3 慢。"slowest": 1 最慢

from queue import *

q = [Queue(), Queue()]
curq = 0

import tkinter as tk

# File = "D:\lc_class\A地理信息系统\作业1\china.e00"

root = tk.Tk()
root.geometry("-" + str(width + edge) + "+100")  # 400x300

label1 = tk.Label(root, text="画矢量图，请输入矢量文件路径(.e00结尾)：")
label1.grid(row=0, column=1, columnspan=3, pady=10, padx=5)
entry1 = tk.Entry(root, width=30)
entry1.grid(row=0, column=2 + 2, rowspan=1, columnspan=5, pady=10, padx=0)
Button1 = tk.Button(root, text="提交", command=sFile_input)
Button1.grid(row=0, column=9, rowspan=1, pady=10, padx=5)

label6 = tk.Label(root, text="矢量转栅格：")
label6.grid(row=1, column=1, columnspan=3, pady=1, padx=0)
label3 = tk.Label(root, text="请输入矢量文件路径(.e00结尾)：")
label3.grid(row=2, column=1, columnspan=3, pady=2, padx=5)
entry3 = tk.Entry(root, width=30)
entry3.grid(row=2, column=2 + 2, rowspan=1, columnspan=5, pady=2, padx=0)
label4 = tk.Label(root, text="请输入期待生成的栅格文件路径：")
label4.grid(row=4, column=1, columnspan=3, pady=2, padx=5)
entry4 = tk.Entry(root, width=30)
entry4.grid(row=4, column=2 + 2, rowspan=1, columnspan=5, pady=2, padx=0)
label5 = tk.Label(root, text="请输入分辨率(建议先点击“推荐分辨率”\n按钮，然后输入系统推荐的分辨率)：")
label5.grid(row=3, column=1, columnspan=3, pady=2, padx=5)
entry5 = tk.Entry(root, width=30)
entry5.grid(row=3, column=2 + 2, rowspan=1, columnspan=5, pady=2, padx=0)
Button3 = tk.Button(root, text="提交", command=s2rFile_input)
Button3.grid(row=5, column=4, rowspan=1, columnspan=5, pady=5, padx=5)

label2 = tk.Label(root, text="画栅格图，请输入栅格文件路径：")
label2.grid(row=6, column=1, columnspan=3, pady=10, padx=5)
entry2 = tk.Entry(root, width=30)
entry2.grid(row=6, column=2 + 2, rowspan=1, columnspan=5, pady=10, padx=0)
Button2 = tk.Button(root, text="提交", command=rFile_input)
Button2.grid(row=6, column=9, rowspan=1, pady=10, padx=5)

Button4 = tk.Button(root, text="清空画布", command=clearscreen)
Button4.grid(row=7, column=8, rowspan=1, columnspan=2, pady=2, padx=5)

Button5 = tk.Button(root, text="放大", command=ZoomIn)
Button5.grid(row=9, column=8, rowspan=1, columnspan=2, pady=2, padx=5)
Button6 = tk.Button(root, text="缩小", command=ZoomOut)
Button6.grid(row=8, column=8, rowspan=1, columnspan=2, pady=2, padx=5)

Button7 = tk.Button(root, text="向上", command=MoveUp)
Button7.grid(row=7, column=2, rowspan=1, columnspan=1, pady=20, padx=5)
label7 = tk.Label(root, text="单击按钮\n移动视野")
label7.grid(row=8, column=2, columnspan=1, pady=2, padx=2)
Button8 = tk.Button(root, text="向左", command=MoveLeft)
Button8.grid(row=8, column=1, rowspan=1, columnspan=1, pady=2, padx=2)
Button9 = tk.Button(root, text="向右", command=MoveRight)
Button9.grid(row=8, column=3, rowspan=1, columnspan=1, pady=2, padx=2)
Button10 = tk.Button(root, text="向下", command=MoveDown)
Button10.grid(row=9, column=2, rowspan=1, columnspan=1, pady=10, padx=5)

label8 = tk.Label(root, text="滑块\n调节\n视野\n移动\n速度\n(数字\n越大\n移动\n越快)")
label8.grid(row=7, column=5, rowspan=3, columnspan=1, pady=2, padx=2)
scale = tk.Scale(root, from_=10, to=100, command=show_selection)
scale.grid(row=7, column=4, rowspan=3, columnspan=1, pady=10, padx=2)

Button11 = tk.Button(root, text="推荐分辨率", command=Recfbl)
Button11.grid(row=2, column=9, rowspan=1, columnspan=1, pady=2, padx=0)

root.mainloop()


